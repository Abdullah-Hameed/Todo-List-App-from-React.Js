import React, { Component } from 'react';


class App extends Component {

constructor(props){
  super(props);
  this.state={
    newItem:"",
    List:[]
  }
}

updateInput(key, value) {
  //update react state
  this.setState({
    [key]: value
  })
}

addItem(){
  //create item with uniqyue id
  const newItem={
  id: 1 + Math.random(),
  value: this.state.newItem.slice()
};

//copy of current list of Items
const List = [...this.state.List];

//add new item to list
List.push(newItem);

//update state with new list and reset newItem input
this.setState({
  List,
  newItem:""

});

}
deleteItem(id){
  //copy current list of items
  const List = [...this.state.List];

  //filter out item being deleted 
  const updatedList = List.filter(item => item.id !== id);
  this.setState({List: updatedList});
}

  render() {
    return (
  <div className="App">

<div>
Add an item...
<br></br>
<input type="text" placeholder="Type item here..." value={this.state.newItem} 
onChange={e => this.updateInput("newItem", e.target.value)}>

</input>

<button onClick= {() => this.addItem()}>
  Add
</button>
<br/>
<ul>

  {this.state.List.map(item => {
    return(
      <li key={item.id}>
        {item.value}
        <button
        onClick={() => this.deleteItem(item.id)}>
        X

        </button>
      </li>
    )
  })}
</ul>
</div>
</div>
  );
}
}
export default App;
